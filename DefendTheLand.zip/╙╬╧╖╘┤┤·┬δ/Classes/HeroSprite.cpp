#include "HeroSprite.h"
HeroSprite::HeroSprite(){

}
HeroSprite::~HeroSprite(){

}