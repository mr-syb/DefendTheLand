#include "AllLevel.h"
AllLevel::AllLevel(){
	
}
AllLevel::~AllLevel(){

}
