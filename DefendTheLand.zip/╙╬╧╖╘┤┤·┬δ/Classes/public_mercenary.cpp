#include "public_mercenary.h"
public_mercenary::public_mercenary(){

}
public_mercenary::~public_mercenary(){

}
float public_mercenary::get_speed(){
	return 0;
}