#include "AllScene.h"
AllScene::AllScene(){

}
AllScene::~AllScene(){

}